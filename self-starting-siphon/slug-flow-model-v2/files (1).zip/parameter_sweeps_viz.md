# Parameter Sweeps and Visualisation Methods

## Overview

This document specifies parameter sweep configurations and visualisation approaches for the self-starting siphon model, including CFD validation requirements.

---

## Part A: Parameter Sweep Configurations

### A.1 Primary Geometric Parameters

#### Sweep 1: Crest Height Variation

| Parameter | Range | Steps | Units |
|-----------|-------|-------|-------|
| `h_crest` | 0.15 → 0.35 | 21 | m |
| Fixed: `h1` | 0.20 | - | m |
| Fixed: `h_inlet` | 0.05 | - | m |
| Fixed: `h_outlet` | -0.30 | - | m |

**Purpose:** Map the priming boundary as crest approaches/exceeds water level.

**Key metric:** Binary priming success + margin $(h_{\max} - h_{\text{crest}})$

---

#### Sweep 2: Outlet Depth Variation

| Parameter | Range | Steps | Units |
|-----------|-------|-------|-------|
| `h_outlet` | -0.10 → -0.50 | 17 | m |
| Fixed: `h_crest` | 0.22 | - | m |
| Fixed: `h1` | 0.20 | - | m |

**Purpose:** Quantify how outlet drop affects driving head and flow rate.

**Key metrics:** Final drain velocity, total drain time, peak Reynolds number.

---

#### Sweep 3: Pipe Length (x-extent) Variation

| Parameter | Range | Steps | Units |
|-----------|-------|-------|-------|
| `x_E` | 0.08 → 0.25 | 18 | m |
| Proportional scaling of `x_B`, `x_C`, `x_D` |

**Purpose:** Understand trade-off between friction losses and momentum storage.

**Key metrics:** Filling time $t^*$, energy efficiency $\eta = \frac{E_{\text{kinetic}}}{E_{\text{potential}}}$

---

### A.2 Physical Parameters

#### Sweep 4: Pipe Diameter

| Parameter | Range | Steps | Units |
|-----------|-------|-------|-------|
| `D` | 0.004 → 0.025 | 22 | m |
| Log-spacing | | |

**Purpose:** Span from capillary-dominated to inertia-dominated regimes.

**Key metrics:** Bond number, peak Re, priming success, fill time.

**Validity flags:** Mark cases where $\text{Bo} < 1$ (capillary regime).

---

#### Sweep 5: Container Size

| Parameter | Range | Steps | Units |
|-----------|-------|-------|-------|
| `A0` | 0.005 → 0.50 | 20 | m² |
| Log-spacing | | |

**Purpose:** Map drawdown sensitivity; approach infinite-container limit.

**Key metrics:** Max velocity achieved, ideal bound accuracy.

---

#### Sweep 6: Minor Loss Coefficient

| Parameter | Range | Steps | Units |
|-----------|-------|-------|-------|
| `K_minor` | 0.0 → 5.0 | 26 | - |

**Purpose:** Assess sensitivity to entrance/bend losses.

**Key metrics:** Priming threshold shift, velocity reduction.

---

#### Sweep 7: Pipe Roughness

| Parameter | Range | Steps | Units |
|-----------|-------|-------|-------|
| `eps_D` | 1e-6 → 1e-2 | 20 | - |
| Log-spacing | | |

**Purpose:** Compare smooth (glass) to rough (3D-printed) pipes.

**Key metrics:** Friction factor range, drain rate variation.

---

### A.3 Multi-Parameter Studies

#### Study 1: Diameter × Crest Height (2D Grid)

```
D:       [0.006, 0.008, 0.010, 0.012, 0.015, 0.020] m  (6 values)
h_crest: [0.16, 0.18, 0.20, 0.22, 0.24, 0.26, 0.28] m  (7 values)
Total:   42 simulations
```

**Visualisation:** Heat map of priming success with contour of $h_{\max} = h_{\text{crest}}$.

---

#### Study 2: Container Size × Roughness (2D Grid)

```
A0:    [0.01, 0.02, 0.05, 0.10, 0.20] m²  (5 values)
eps_D: [1e-5, 1e-4, 1e-3, 1e-2]          (4 values)
Total: 20 simulations
```

**Visualisation:** Contour plot of fill time or drain rate.

---

#### Study 3: Geometry Optimisation (Latin Hypercube)

Sample 200 random configurations from:

| Parameter | Min | Max |
|-----------|-----|-----|
| `h_crest` | 0.18 | 0.30 |
| `h_outlet` | -0.40 | -0.15 |
| `h_ubend` | -0.20 | 0.00 |
| `x_E` | 0.10 | 0.20 |
| `D` | 0.008 | 0.018 |

**Purpose:** Identify Pareto-optimal designs (maximise drain rate, minimise fill time, ensure priming).

---

## Part B: Visualisation Methods

### B.1 Time-Series Plots

#### Standard 4-Panel Figure

```python
fig, axes = plt.subplots(2, 2, figsize=(12, 10))

# Panel 1: Geometry schematic
# Panel 2: L(t) during filling
# Panel 3: v(t) for both phases
# Panel 4: h_c(t) and h_front(t)
```

**Configuration:**
- DPI: 150 (screen), 300 (publication)
- Font: 10pt sans-serif
- Grid: alpha=0.3
- Colour scheme: filling=blue, draining=red, limits=dashed grey

---

### B.2 Phase Space Diagrams

#### (L, v) Phase Portrait

Plot velocity vs position during filling to visualise dynamics:

```python
plt.figure(figsize=(8, 6))
plt.plot(L_fill * 100, v_fill * 100, 'b-', lw=2)
plt.axhline(0, color='k', alpha=0.3)
plt.axvline(p.Lmax * 100, color='g', ls='--', label='L_max')
```

**Annotations:**
- Mark stall point if priming fails
- Overlay ideal (lossless) trajectory for comparison

---

#### (h_c, v) Drain Phase Portrait

```python
plt.plot(hc_drain * 100, v_drain * 100, 'r-', lw=2)
```

Shows approach to equilibrium or oscillatory behaviour.

---

### B.3 Parameter Sensitivity Plots

#### Tornado Diagram

For a baseline design, show ±10% parameter variation impact on fill time:

```python
params = ['D', 'A0', 'eps_D', 'K_minor', 'h_crest']
sensitivities = [...]  # Compute dT/dP * P/T

plt.barh(params, sensitivities)
plt.xlabel('Normalised Sensitivity')
```

---

#### Priming Boundary Map

2D contour plot showing the critical surface $h_{\max} = h_{\text{crest}}$:

```python
plt.contourf(D_grid, h_crest_grid, priming_success, levels=[0, 0.5, 1])
plt.contour(D_grid, h_crest_grid, margin, levels=[0], colors='red', linewidths=2)
```

---

### B.4 Animation

#### Fill Progression Animation

Create frames showing water front advancing through geometry:

```python
from matplotlib.animation import FuncAnimation

def update(frame):
    L_current = L_fill[frame]
    # Draw pipe with filled portion highlighted
    # Update water level marker
    # Show current time and velocity

ani = FuncAnimation(fig, update, frames=len(t_fill), interval=50)
ani.save('filling.gif', writer='pillow')
```

**Settings:**
- Frame rate: 20 fps
- Duration: Real-time or 2× speed
- Format: GIF or MP4

---

### B.5 Statistical Visualisations

#### Box Plot of Fill Times

For Monte Carlo / Latin Hypercube studies:

```python
plt.boxplot([fill_times_smooth, fill_times_rough], 
            labels=['Smooth', 'Rough'])
```

---

#### Pareto Front

For multi-objective optimisation:

```python
plt.scatter(drain_rate, -fill_time, c=priming_success, cmap='RdYlGn')
# Highlight Pareto-optimal points
```

---

## Part C: CFD Validation Specifications

### C.1 Recommended CFD Codes

#### Primary: OpenFOAM (interFoam)

**Version:** OpenFOAM v2312 (ESI-OpenCFD) or OpenFOAM 11 (Foundation)

**Solver:** `interFoam` — VOF multiphase solver for incompressible immiscible fluids

**Why:** Free, well-documented, cited in theory paper, excellent for free-surface flows.

---

#### Alternative: ANSYS Fluent

**Version:** 2024 R1 or newer

**Model:** Volume of Fluid (VOF) with implicit body force treatment

**Why:** Better GUI, established validation database, may be available at university.

---

### C.2 OpenFOAM Setup

#### Mesh Requirements

| Region | Cell Size | Inflation Layers |
|--------|-----------|------------------|
| Pipe core | D/20 | - |
| Wall boundary | D/40 | 5 layers, growth=1.2 |
| Free surface zone | D/30 | - |
| Inlet/outlet | D/15 | 3 layers |

**Total cells:** ~200k–500k for 3D; ~20k for 2D axisymmetric

---

#### Boundary Conditions

```
inlet
{
    type            pressureInletOutletVelocity;
    value           uniform (0 0 0);
}

outlet
{
    type            inletOutlet;
    inletValue      uniform (0 0 0);
    value           uniform (0 0 0);
}

walls
{
    type            noSlip;
}

atmosphere
{
    type            totalPressure;
    p0              uniform 101325;
}
```

---

#### Turbulence Model

For Re < 2300: Laminar (no turbulence model)

For Re > 2300: k-ω SST with:
```
kOmegaSST
{
    alphaK1         0.85;
    alphaK2         1.0;
    alphaOmega1     0.5;
    alphaOmega2     0.856;
    ...
}
```

---

#### Time Stepping

```
deltaT          1e-5;        // Initial
maxCo           0.5;         // Courant limit
maxAlphaCo      0.3;         // Interface Courant
adjustTimeStep  yes;
maxDeltaT       1e-3;
```

**Total simulation time:** 2–5 seconds (depends on geometry)

---

#### Post-Processing

Extract from OpenFOAM:
1. `alpha.water` field at each timestep → front position
2. `U` field → velocity profiles
3. `p_rgh` → pressure distribution
4. Force integration on walls → drag validation

---

### C.3 Validation Test Cases

#### Case 1: Straight Vertical Tube

**Purpose:** Validate filling dynamics without bends

**Geometry:** Single segment, A→E vertical drop of 0.3 m

**Comparison:** Theoretical free-fall + friction should match CFD within 5%

---

#### Case 2: U-Tube Oscillation

**Purpose:** Validate momentum equation in draining/oscillating regime

**Setup:** Symmetric U-tube, initial offset, measure oscillation frequency

**Theory:** $f = \frac{1}{2\pi}\sqrt{\frac{2g}{L}}$ (undamped)

---

#### Case 3: Full Self-Starting Geometry

**Purpose:** Validate complete priming sequence

**Geometry:** Standard 5-node configuration from `main()`

**Comparison metrics:**

| Metric | 1D Model | CFD Target Agreement |
|--------|----------|----------------------|
| Priming (yes/no) | ✓/✗ | Must match |
| Fill time | $t^*$ | Within 15% |
| Peak velocity | $v_{\max}$ | Within 20% |
| Drain rate | $Q_{\text{drain}}$ | Within 10% |

---

### C.4 CFD Mesh Files

Generate with `blockMesh` or Gmsh:

```bash
# blockMesh (simple geometries)
cd $CASE/constant/polyMesh
blockMesh

# Gmsh (complex geometries)
gmsh -3 siphon.geo -o siphon.msh
gmshToFoam siphon.msh
```

**Gmsh version:** 4.11.1 or newer (for proper OpenFOAM export)

---

### C.5 Hardware Requirements

| Simulation Type | Cores | RAM | Time |
|-----------------|-------|-----|------|
| 2D axisymmetric | 4 | 8 GB | ~1 hour |
| 3D coarse (200k cells) | 8 | 16 GB | ~6 hours |
| 3D fine (500k cells) | 16 | 32 GB | ~24 hours |

---

## Part D: Data Management

### D.1 Output File Structure

```
results/
├── sweeps/
│   ├── crest_height/
│   │   ├── sweep_config.json
│   │   ├── results.csv
│   │   └── figures/
│   ├── diameter/
│   └── ...
├── cfd/
│   ├── case_001/
│   │   ├── constant/
│   │   ├── system/
│   │   └── postProcessing/
│   └── ...
└── comparison/
    ├── 1d_vs_cfd.csv
    └── validation_plots/
```

### D.2 CSV Column Specifications

```csv
case_id,D,h_crest,A0,eps_D,K_minor,primed,t_fill,v_max,h_max_reached,t_drain,notes
```

### D.3 Recommended Plotting Library

**Primary:** Matplotlib 3.8+ with SciPy

**Publication quality:** Consider Seaborn for statistical plots

**Interactive:** Plotly for parameter exploration dashboards

---

## Quick Reference: Simulation Commands

```bash
# Single simulation
python simulation_code.py

# Parallel sweep (using joblib)
python run_sweep.py --param D --range 0.004:0.025:22 --output results/diameter/

# CFD case setup
./Allrun  # OpenFOAM standard script

# Post-process CFD
foamToVTK -latestTime
paraview case.foam
```
