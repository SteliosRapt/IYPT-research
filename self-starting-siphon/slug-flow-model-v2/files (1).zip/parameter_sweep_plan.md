# Parameter Sweep Plan

## Executive Summary

This plan outlines a systematic parameter study for the self-starting siphon model to:
1. Map the priming boundary in geometry space (drop depth vs climb height)
2. Identify the critical loss coefficient threshold
3. Validate the ideal bound prediction (Eq. 28)
4. Generate data for IYPT presentation

**Key physical insight:** Self-starting siphons accumulate momentum during an initial drop (B→C) and use it to climb above the water level to the crest (D). The priming boundary is governed by the energy integral equation.

**Total computational budget:** ~300 simulations (~2 minutes on single core)

---

## Phase 1: Baseline Validation (Day 1)

### 1.1 Verify Default Configuration

Run the example geometry from `main()` and confirm:
- [ ] Priming succeeds
- [ ] Fill time ~ 0.1–0.5 s
- [ ] Ideal bound margin > 0

**Expected output:** Baseline metrics for comparison

### 1.2 Numerical Convergence Check

| Test | rtol | atol | max_step | Expected |
|------|------|------|----------|----------|
| Coarse | 1e-6 | 1e-8 | 0.5 | Baseline |
| Medium | 1e-8 | 1e-10 | 0.1 | Reference |
| Fine | 1e-10 | 1e-12 | 0.01 | Converged |

**Acceptance:** Medium and Fine results agree within 1% on fill time.

---

## Phase 2: Single-Parameter Sweeps (Days 2-3)

### 2.1 Geometric Parameters

#### Sweep A: Crest Height

```python
h_crest_values = np.linspace(0.15, 0.30, 16)  # 16 points
# Fixed: h1=0.20, h_outlet=-0.30, D=0.012
```

**Output columns:** `h_crest`, `primed`, `h_max`, `margin`, `t_fill`, `v_max`

**Deliverable:** Plot of priming boundary, identify critical crest height

---

#### Sweep B: Outlet Depth

```python
h_outlet_values = np.linspace(-0.10, -0.50, 17)  # 17 points
# Fixed: h_crest=0.22, h1=0.20, D=0.012
```

**Output columns:** `h_outlet`, `primed`, `t_fill`, `t_drain`, `v_drain_final`

**Deliverable:** Drain rate vs outlet depth relationship

---

#### Sweep C: U-Bend Depth

```python
h_ubend_values = np.linspace(-0.25, 0.05, 13)  # 13 points
# Fixed: h_crest=0.22, h_outlet=-0.30
```

**Output:** Effect of internal loop depth on priming

---

### 2.2 Physical Parameters

#### Sweep D: Pipe Diameter (PRIMARY)

```python
D_values = np.logspace(np.log10(0.004), np.log10(0.025), 20)
# 4 mm to 25 mm, log-spaced
```

**Critical thresholds to identify:**
- Capillary regime onset (Bo < 1 → D < ~2.7 mm)
- Transition to turbulence (Re = 2300)

**Output columns:** `D`, `Bo`, `Re_max`, `primed`, `t_fill`, `regime`

---

#### Sweep E: Container Cross-Section

```python
A0_values = np.logspace(-2.3, -0.3, 15)  # 0.005 to 0.5 m²
```

**Purpose:** Approach infinite-container limit; test drawdown sensitivity

---

#### Sweep F: Minor Losses

```python
K_values = np.linspace(0, 5, 21)
```

**Purpose:** Sensitivity to entrance/bend coefficients; guides experimental setup

---

#### Sweep G: Roughness

```python
eps_D_values = np.logspace(-6, -2, 17)
```

**Purpose:** Compare smooth (glass) vs rough (3D print) scenarios

---

## Phase 3: Two-Parameter Studies (Days 4-5)

### 3.1 Diameter × Crest Height Grid

```python
D_grid = [0.006, 0.008, 0.010, 0.012, 0.015, 0.020]  # 6 values
h_crest_grid = [0.16, 0.18, 0.20, 0.22, 0.24, 0.26]  # 6 values
# Total: 36 simulations
```

**Deliverable:** 2D heatmap showing priming success region

---

### 3.2 Container × Roughness Grid

```python
A0_grid = [0.01, 0.02, 0.05, 0.10]       # 4 values
eps_D_grid = [1e-5, 1e-4, 1e-3, 1e-2]     # 4 values
# Total: 16 simulations
```

**Deliverable:** Contour plot of fill time

---

### 3.3 Outlet × Crest Interaction

```python
h_outlet_grid = [-0.15, -0.25, -0.35, -0.45]  # 4 values
h_crest_grid = [0.18, 0.22, 0.26]              # 3 values
# Total: 12 simulations
```

**Purpose:** Understand how outlet depth compensates for higher crests

---

## Phase 4: Extreme/Boundary Cases (Day 6)

### 4.1 Failure Mode Exploration

| Case | Configuration | Expected Outcome |
|------|---------------|------------------|
| F1 | h_crest = h1 + 0.05 | Stall before crest |
| F2 | D = 0.003 (small) | Capillary dominance |
| F3 | K_minor = 10 | Heavy losses prevent priming |
| F4 | A0 = 0.001 (tiny container) | Rapid drawdown |
| F5 | eps_D = 0.1 (very rough) | Excessive friction |

---

### 4.2 Limiting Cases

| Case | Configuration | Theoretical Limit |
|------|---------------|-------------------|
| L1 | A0 → ∞ | No drawdown; ideal bound exact |
| L2 | eps_D → 0, K=0 | Lossless dynamics |
| L3 | D → ∞ | Inertia-dominated; Bo → ∞ |

---

## Phase 5: Latin Hypercube Sampling (Day 7)

### 5.1 Design Space

| Parameter | Min | Max | Distribution |
|-----------|-----|-----|--------------|
| h_crest | 0.17 | 0.28 | Uniform |
| h_outlet | -0.45 | -0.15 | Uniform |
| h_ubend | -0.22 | 0.02 | Uniform |
| D | 0.006 | 0.020 | Log-uniform |
| A0 | 0.01 | 0.20 | Log-uniform |
| K_minor | 0.5 | 3.0 | Uniform |

### 5.2 Sampling

```python
from scipy.stats import qmc

sampler = qmc.LatinHypercube(d=6)
samples = sampler.random(n=100)  # 100 configurations
```

### 5.3 Analysis

- Global sensitivity analysis (Sobol indices)
- Surrogate model fitting (Gaussian Process)
- Pareto front identification (fill time vs drain rate)

---

## Implementation Code Structure

### File: `run_sweeps.py`

```python
#!/usr/bin/env python3
"""Automated parameter sweep runner."""

import numpy as np
import pandas as pd
from pathlib import Path
from simulation_code import *

def run_single_sweep(param_name, values, base_config, output_dir):
    """Run sweep over single parameter."""
    results = []
    for val in values:
        config = base_config.copy()
        config[param_name] = val
        
        try:
            params = create_params_from_config(config)
            result = simulate(params)
            h_max, _, _ = compute_ideal_bound(params)
            
            results.append({
                param_name: val,
                'primed': result.primed,
                't_fill': result.t_prime if result.primed else None,
                'h_max': h_max,
                'margin': h_max - params.h_crest,
                'v_max': np.max(result.v_fill),
                'Bo': params.bond_number(),
                'Re_max': params.reynolds(np.max(result.v_fill)),
            })
        except Exception as e:
            results.append({param_name: val, 'error': str(e)})
    
    df = pd.DataFrame(results)
    df.to_csv(output_dir / f'sweep_{param_name}.csv', index=False)
    return df

# Sweep configurations
SWEEPS = {
    'h_crest': np.linspace(0.15, 0.30, 16),
    'h_outlet': np.linspace(-0.10, -0.50, 17),
    'D': np.logspace(np.log10(0.004), np.log10(0.025), 20),
    'A0': np.logspace(-2.3, -0.3, 15),
    'K_minor': np.linspace(0, 5, 21),
    'eps_D': np.logspace(-6, -2, 17),
}
```

---

## Expected Outputs

### CSV Files

| File | Rows | Columns |
|------|------|---------|
| `sweep_h_crest.csv` | 16 | 8 |
| `sweep_h_outlet.csv` | 17 | 8 |
| `sweep_D.csv` | 20 | 10 |
| `sweep_A0.csv` | 15 | 8 |
| `sweep_K_minor.csv` | 21 | 8 |
| `sweep_eps_D.csv` | 17 | 8 |
| `grid_D_hcrest.csv` | 36 | 10 |
| `lhs_samples.csv` | 100 | 15 |

---

### Figures

| Figure | Format | Purpose |
|--------|--------|---------|
| `priming_boundary.png` | 300 DPI | D vs h_crest heatmap |
| `diameter_sweep.png` | 300 DPI | Fill time vs D |
| `sensitivity_tornado.png` | 300 DPI | Parameter importance |
| `pareto_front.png` | 300 DPI | Multi-objective trade-off |
| `phase_portraits.png` | 150 DPI | L-v diagrams |

---

## Timeline

| Day | Tasks | Est. Runtime |
|-----|-------|--------------|
| 1 | Baseline + convergence | 10 min |
| 2 | Sweeps A-C (geometric) | 5 min |
| 3 | Sweeps D-G (physical) | 10 min |
| 4 | 2D grid studies | 5 min |
| 5 | Analysis + plotting | — |
| 6 | Extreme cases | 5 min |
| 7 | LHS + global sensitivity | 15 min |

**Total simulation time:** ~50 minutes
**Analysis time:** ~3 hours

---

## Success Criteria

1. **Priming boundary mapped:** Clear contour separating priming/failure regions
2. **Sensitive parameters identified:** Ranked by impact on fill time
3. **Regime transitions located:** Bo=1 threshold, Re=2300 transition
4. **CFD validation cases selected:** 3-5 representative cases for comparison
5. **Publication-ready figures:** All plots in consistent style

---

## Risk Mitigation

| Risk | Mitigation |
|------|------------|
| Solver convergence failure | Reduce max_step, increase tolerances |
| Invalid geometries | Pre-validate with `validate_geometry_constraints` |
| Memory overflow (many runs) | Process sweeps sequentially, clear results |
| Missing physics (small D) | Flag Bo < 1 cases; note capillary limitation |
