# Overview of Siphon Theory Paper

## Document Metadata

| Field | Value |
|-------|-------|
| **Title** | One-Dimensional Slug-Flow Model for Self-Starting Siphons: Theory, Bounds, and Computation |
| **Author** | Stylianos Raptopoulos |
| **Date** | 24/11/2025 |
| **Context** | IYPT 2026 Problem #1 |
| **LaTeX Class** | article (11pt) |

---

## Abstract Summary

The document develops a **1D slug-flow model** connecting geometric and physical parameters to observable outcomes (priming success, filling time, draining rate). Three main results are derived:

1. **Analytical upper bound** $h_{\max}$ for maximum climb height (closed form for piecewise-linear geometries)
2. **Geometric priming criterion** $h_{\max} > h_{\text{crest}}$ for rapid design screening
3. **Explicit ODEs** for full time evolution with Churchill friction and minor losses

---

## Document Structure

### Section 1: Introduction
- **1.1** IYPT problem statement (verbatim quote)
- **1.2** Physical mechanism: explains how self-starting siphons differ from conventional inverted-U siphons; key insight is the extended positive driving head allowing momentum buildup
- **1.3** Document roadmap

### Section 2: Problem Setup
- **2.1** Coordinate system: 2D vertical plane $(x, h)$, $h=0$ at container base
- **2.2** Five-node geometry: $A \to B \to C \to D \to E$ with four straight segments
  - Node $A$: inlet (at container wall)
  - Node $D$: crest (highest point)
  - Node $E$: outlet
- **2.3** Arclength parameterisation with cumulative lengths $S_i$
- **2.4** Piecewise-linear elevation function: $h(L) = c_i + s_i L$ on segment $i$
- **2.5** State variables: wetted length $L(t)$ and container level $h_c(t)$
- **2.6** Parameter table: $A_0$, $A$, $D$, $\rho$, $\mu$, $\varepsilon/D$, $\sum K_i$

### Section 3: Mass Conservation
- **3.1** Volume balance: $V_{\text{cont}} + V_{\text{pipe}} = \text{const}$
- **3.2** Initial conditions: $L(0) = L_1$, $\dot{L}(0) = 0$, $h_c(0) = h_0$
- **3.3** **Key relation**: $h_c(L) = h_0 - \frac{A}{A_0}(L - L_1)$ (Eq. 13)

### Section 4: Momentum Balance
- **4.1** Setup: slug of length $L(t)$ with uniform velocity $v(t) = \dot{L}(t)$
- **4.2** Force analysis on thin slice $d\xi$
- **4.3** Integration along the slug
- **4.4** Boundary conditions (inlet hydrostatic, front atmospheric)
- **4.5** **Fundamental result**: $F_{\text{drive}} = \rho g A [h_c(t) - h(L(t))]$ (Eq. 18)
- **4.6** Lossless equation of motion: $\ddot{L} = \frac{g}{L}[h_c - h(L)]$ (Eq. 19)

### Section 5: Filling Phase Dynamics
- **5.1** Loss models:
  - Darcy-Weisbach friction: $h_f = f \frac{\ell}{D} \frac{v^2}{2g}$
  - Churchill correlation (Eqs. 20-22) spanning all flow regimes
  - Minor losses: $h_m = K \frac{v^2}{2g}$
- **5.2** **Complete filling ODE** (Eq. 25):
$$\ddot{L} = \frac{g}{L}\left[h_0 - \frac{A}{A_0}(L - L_1) - h(L)\right] - \frac{1}{2L}\left(f\frac{L}{D} + \sum K_i\right)|\dot{L}|\dot{L}$$
- **5.3** Characteristic scales: $L_{\max}$, $v_0 \sim \sqrt{g\Delta h}$, $\tau \sim \sqrt{L_{\max}/g}$

### Section 6: Analytical Bounds
- **6.1** Ideal model assumptions: no drawdown, no losses
- **6.2** Energy integral via chain rule: $\frac{v^2}{2} = g\int_{L_1}^{L}\frac{h_0 - h(\xi)}{\xi}d\xi$ (Eq. 27)
- **6.3** **Stall condition**: $\int_{L_1}^{L_{\text{stall}}}\frac{h_0 - h(\xi)}{\xi}d\xi = 0$ (Eq. 28)
- **6.4** Closed-form evaluation using segment contribution function:
$$\Phi_i(a,b) = (h_0 - c_i)\ln\frac{b}{a} - s_i(b-a)$$
- **6.5** **Priming criterion**: $h_{\max} > h_3$ (crest elevation)
- **6.6** Three uses of the bound: rapid screening, parameter insight, diagnostic

### Section 7: Draining Phase
- **7.1** State: $(h_c(t), v(t))$ with fixed $L = L_{\max}$
- **7.2** Mass balance: $\dot{h}_c = -\frac{A}{A_0}v$ (Eq. 33)
- **7.3** Momentum: $\dot{v} = \frac{g}{L_{\max}}[h_c - h_{\text{out}}] - \frac{1}{2L_{\max}}(\text{loss})|v|v$ (Eq. 34)
- **7.4** Initial conditions from filling phase end

### Section 8: Validity Limits
- **8.1** Modelling assumptions: incompressible Newtonian fluid, rigid pipe, quasi-hydrostatic container, single slug
- **8.2** Cavitation constraint: $h_c - h_{\text{crest}} - h_{\text{loss}} \geq h_{\text{vap}} \approx 10.3\,\text{m}$
- **8.3** Capillarity: Bond number $\text{Bo} = \rho g D^2 / \sigma \gg 1$ required
- **8.4** Flow regime: Reynolds number and quasi-steady friction assumption
- **8.5** Breakdown conditions: 3D separation, air entrainment, column separation, large turbulent fluctuations
- **8.6** Validity checklist (5 items)

### Section 9: Computational Implementation
- **9.1** Algorithm: two sequential IVPs (filling → draining)
- **9.2** Reference to external `simulation_code.py`

### Section 10: Model Summary
- Key equations table (6 equations)
- Recommended IYPT workflow (7 steps)

### Section 11: Conclusions
- Lists 7 main contributions
- Suggests future extensions: cavitation switch, meniscus-start model, multi-slug tracking, CFD comparison

---

## Key Equations Reference

| Eq. # | Name | Expression |
|-------|------|------------|
| (13) | Container drawdown | $h_c(L) = h_0 - \frac{A}{A_0}(L - L_1)$ |
| (18) | Driving force | $F_{\text{drive}} = \rho g A[h_c - h(L)]$ |
| (25) | Filling ODE | Full second-order ODE with losses |
| (28) | Stall condition | Energy integral equals zero |
| (31) | Priming criterion | $h_{\max} > h_3$ |
| (33)-(34) | Draining system | Coupled $h_c$, $v$ ODEs |

---

## Bibliography Analysis

The paper cites 18 references spanning:

- **Classical fluid mechanics**: White (textbook), Moody, Colebrook
- **Friction correlations**: Churchill (1977) — the primary friction model
- **Siphon physics**: Potter & Barnes, Hughes, Jumper & Stanchev, Zheng et al.
- **CFD references**: OpenFOAM interFoam, ANSYS Fluent
- **Cavitation/negative pressure**: Boatwright et al., Vera et al., Caupin & Herbert
- **Numerical methods**: Hairer (ODE solvers), SciPy

---

## Notation Conventions

The document uses a careful distinction between:

- $h_0$ = inlet elevation (node A)
- $h_1$ = initial water level / container surface = $h_B$
- $h_3$ = crest elevation (node D)
- $h_c(t)$ = time-varying container surface

The simulation code mirrors this with `h0` (inlet) and `h1` (water level).

---

## Strengths

1. **Rigorous derivation** from first principles with clear assumptions
2. **Closed-form bounds** enabling rapid geometric screening
3. **Complete loss modelling** (Churchill + minors) spanning all Re
4. **Explicit validity criteria** with physical justification
5. **Well-structured** for IYPT presentation

## Potential Gaps

1. No treatment of **meniscus pinning** at small diameters
2. No **transient friction** model (Zielke-type)
3. **Multi-slug dynamics** after cavitation not modelled
4. No direct **CFD validation data** within the document
