# Code Overview: simulation_code.py

## File Metadata

| Property | Value |
|----------|-------|
| **Language** | Python 3 |
| **Lines** | 507 |
| **Dependencies** | numpy, scipy (integrate, optimize), dataclasses, typing |
| **Entry Point** | `main()` function |

---

## Architecture Overview

```
simulation_code.py
├── churchill_friction()         # Friction factor for all regimes
├── validate_geometry_constraints()  # 5-constraint checker
├── create_valid_geometry()      # Geometry factory
├── PipeGeometry (dataclass)     # Geometry container
├── SiphonParams (dataclass)     # Full parameter set
├── filling_rhs()                # Filling phase ODE RHS
├── draining_rhs()               # Draining phase ODE RHS
├── SimulationResult (dataclass) # Results container
├── simulate()                   # Main simulation driver
├── segment_energy()             # Φ function for ideal bound
├── compute_ideal_bound()        # h_max calculator
├── validate_setup()             # Pre-simulation checks
├── plot_results()               # Matplotlib visualisation
├── print_summary()              # Console output
└── main()                       # Example runner
```

---

## Key Components

### 1. Churchill Friction Factor (lines 28-38)

```python
def churchill_friction(Re: float, eps_D: float) -> float
```

- Implements Equations (20)-(22) from theory
- Handles Re < 1 with laminar fallback `64/Re`
- Numerical guards: `max(Re, 1e-10)`, `min(..., 1e100)` to prevent overflow

### 2. Geometry Validation (lines 41-84)

Enforces 5 constraints:
1. $x_A = 0$
2. $x$ strictly increasing
3. $h_D$ is maximum (crest)
4. $h_B = h_1$ (water level)
5. Two lowest among {A, C, E}, second lowest is C or E

### 3. PipeGeometry Dataclass (lines 113-162)

**Fields computed in `__post_init__`:**
- `L_segments`: segment lengths $L_i = \sqrt{dx^2 + dh^2}$
- `S`: cumulative arclengths $[0, S_1, S_2, S_3, S_4]$
- `slopes`: $s_i = dh_i / L_i$
- `intercepts`: $c_i = h_{i-1} - s_i S_{i-1}$
- `crest_index`: index of maximum elevation

**Key methods:**
- `h_of_L(L)`: piecewise-linear elevation
- `segment_of_L(L)`: which segment contains L

### 4. SiphonParams Dataclass (lines 165-203)

**Default physical parameters:**

| Parameter | Default | Description |
|-----------|---------|-------------|
| `g` | 9.81 m/s² | Gravity |
| `rho` | 1000 kg/m³ | Density |
| `mu` | 1.0e-3 Pa·s | Viscosity |
| `D` | 0.010 m | Pipe diameter |
| `A0` | 0.02 m² | Container area |
| `eps_D` | 1.0e-4 | Relative roughness |
| `K_minor` | 1.0 | Minor loss (filling) |
| `K_drain` | 1.5 | Minor loss (draining) |

**Derived properties:**
- `A = π D² / 4`
- `area_ratio = A / A0`
- `bond_number()`

### 5. ODE Functions (lines 206-223)

**Filling RHS** (matches Eq. 25):
```python
dvdt = (g/L) * (hc - h_front) - (0.5/L) * loss * |v| * v
```

**Draining RHS** (matches Eqs. 33-34):
```python
dhc_dt = -area_ratio * v
dv_dt = (g/Lmax) * (hc - h_outlet) - (0.5/Lmax) * loss * |v| * v
```

### 6. Simulation Driver (lines 246-291)

**Events for filling phase:**
1. `ev_filled`: $L = L_{\max}$ (priming success)
2. `ev_stall`: $v = 0$ (velocity reversal)
3. `ev_head`: $h_c = h(L)$ (head exhausted)

**Integration settings:**
- Solver: `solve_ivp` (default RK45)
- `rtol=1e-8`, `atol=1e-10`
- `max_step=0.1` s

### 7. Ideal Bound Computation (lines 294-332)

Implements Equations (29)-(32):
```python
def segment_energy(h1, c, s, a, b):
    return (h1 - c) * np.log(b/a) - s * (b - a)
```

Uses `brentq` for root-finding when cumulative integral becomes negative.

---

## Consistency with Theory Document

### ⚠️ Notation Clarification Needed: h₀ in Ideal Bound

**Theory (Eq. 27):**
$$\frac{v^2}{2} = g \int_{L_1}^{L} \frac{h_0 - h(\xi)}{\xi} d\xi$$

The notation $h_0$ here refers to the **constant container level** in the ideal (no-drawdown) model, which equals $h_1 = h_B$ (the initial water level).

**Code (lines 294-332):**
```python
def segment_energy(h1, c, s, a, b):
    return (h1 - c) * np.log(b/a) - s * (b - a)
```

The code correctly uses `h1` (water level). The theory could benefit from clarifying that $h_0$ in the ideal model equals $h_c(0) = h_1$.

---

### ✓ Geometry Constraints Are Correct

The constraints enforced by `validate_geometry_constraints()` are physically correct for self-starting siphons:

1. **h_D is maximum** — The crest (D) must be the highest point; this is what makes priming challenging
2. **h_B = h_1** — Node B is at the water surface level, where the filling phase begins
3. **Two lowest among {A,C,E}** — Ensures proper U-bend and outlet positioning

The research question is: given that D is above the water level, does the momentum accumulated during B→C (the drop) suffice to carry the slug up to D?

---

### ✓ Initial Condition Handling

**Theory (Eq. 16):** $L(0) = L_1$, $\dot{L}(0) = 0$

**Code (line 259):** `[p.L1, 0.0]`

At this initial condition, the driving head $h_c - h(L_1) = h_1 - h_B = 0$. This creates a degenerate case where the ODE gives zero acceleration.

**Physical interpretation:** In reality, the system requires a small perturbation (capillary effects, surface disturbances, or residual motion from the filling process) to initiate motion. Adding a small initial velocity (v₀ ≈ 1 mm/s) correctly models this physical reality.

---

### Different Minor Loss Coefficients for Filling vs Draining

**Code:**
- `K_minor = 1.0` (filling phase, line 175)
- `K_drain = 1.5` (draining phase, line 176)

**Theory:** Uses a single $\sum K_i$ throughout, not distinguishing between phases.

**Recommendation:** Add a note to the theory that different K values may apply:
- Filling: entrance loss + bend losses only for wetted portion
- Draining: full pipe including exit loss

---

## Suggested Code Improvements

### 1. Add Variable Timestep Control

**Current:** Fixed `max_step=0.1`

**Issue:** This may be too coarse for fast transients or wasteful for slow draining.

**Fix:**
```python
max_step = min(0.1, 0.01 * np.sqrt(p.Lmax / p.g))  # Adaptive to characteristic time
```

### 2. Expose Tolerances as Parameters

```python
@dataclass
class SiphonParams:
    # ... existing fields ...
    rtol: float = 1e-8
    atol: float = 1e-10
```

### 3. Add Cavitation Check

**Missing from code:** The validity section (Section 8.2) describes cavitation limits, but `validate_setup()` doesn't check them.

```python
def check_cavitation(p: SiphonParams, h_crest: float) -> str:
    h_vap = 10.3  # m (approximate)
    p_margin = p.h1 - h_crest
    if p_margin > h_vap:
        return f"CAVITATION RISK: margin {p_margin:.2f}m > {h_vap}m"
    return None
```

### 4. Support Non-Water Fluids

Currently hardcoded for water. Add fluid presets:

```python
FLUIDS = {
    'water': {'rho': 1000, 'mu': 1e-3, 'sigma': 0.072},
    'glycerol': {'rho': 1261, 'mu': 1.412, 'sigma': 0.063},
    'ethanol': {'rho': 789, 'mu': 1.2e-3, 'sigma': 0.022},
}
```

### 5. Add Energy Balance Diagnostic

Track total mechanical energy to verify conservation/dissipation:

```python
def compute_energy(L, v, hc, p):
    KE = 0.5 * p.rho * p.A * L * v**2
    PE_pipe = p.rho * p.g * p.A * integral_of_h_over_L
    PE_container = p.rho * p.g * p.A0 * hc**2 / 2
    return KE + PE_pipe + PE_container
```

### 6. Vectorise `h_of_L` for Arrays

**Current:**
```python
hc_fill = np.array([p.hc_of_L(L) for L in L_fill])  # List comprehension
```

**Better:** Already has `h_of_L_vec`, but not using it consistently. Add:

```python
def hc_of_L_vec(self, L_arr):
    return self.h1 - self.area_ratio * (L_arr - self.L1)
```

---

## Test Coverage Gaps

The code lacks unit tests for:

1. **Geometry edge cases:** What if segments are nearly vertical ($|s_i| \to 1$)?
2. **Low Reynolds:** Behaviour as $\text{Re} \to 0$
3. **Large containers:** Limit $A_0 \to \infty$ should recover lossless case
4. **Boundary cases:** $L_1$ at segment boundary

---

## Summary Table

| Issue | Severity | Location | Recommendation |
|-------|----------|----------|----------------|
| h₀ vs h₁ notation | High | Eq. (13), line 200 | Clarify theory notation |
| Ideal bound h₀ | Medium | Eq. (27), line 302 | Use h₁ explicitly in theory |
| Split K values | Low | lines 175-176 | Document in theory |
| No cavitation check | Medium | validate_setup() | Add check function |
| Fixed max_step | Low | line 260 | Make adaptive |
| List comprehensions | Low | line 263 | Use vectorised methods |
